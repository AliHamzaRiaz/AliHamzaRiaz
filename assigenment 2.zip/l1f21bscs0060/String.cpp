#include "String.h"
String::String()
{
	cha = new char();
	*cha = { '\0'};
}
String::String(const char* s)
{
	int size=0;
	
	for (int i = 0; s[i] != '\0'; i++)
	{
		size ++;
	}
	int size1 = size;
	
	cha = new char[size1+1];
		for (int i = 0; i <=size1; i++)
		{
			cha[i] = s[i];
		}
		
}
String::String(const String& str)
{
	int size = 0;
	for (int i = 0; str.cha[i] != '\0'; i++)
	{
		size++;
	}
	int size1 = size;

	cha = new char[size1 + 1];
	for (int i = 0; i <= size1; i++)
	{
		cha[i] = str.cha[i];
	}

}
String::String(const String& str, int pos, int len)
{
	int size = 0;
	for (int i = 0; str.cha[i] != '\0'; i++)
	{
		size++;
	}
	int size1 = size;
	char* a;
	a = new char[size1 + 1];
	for (int i = 0; i <= size1; i++)
	{
		a[i] = str.cha[i];
	}
	cha = new char[len + 1];
	for (int i = 0;i<len;i++)
	{
		cha[i]=a[pos+i];
	}
	cha[len] = { '\0' };
}
String::String(const char* s, int n)
{
	cha = new char[n + 1];
	for (int i = 0; i < n; i++)
	{
		cha[i] = s[i];
	}
	cha[n] = { '\0' };
}
String::String(int n, char c)
{
	cha = new char[n];
	for (int i = 0; i < n; i++)
	{
		cha[i] = c;
	}
	cha[n] = { '\0' };
}
String String:: substr(int pos, int len) const
{
	String res;
	char* a;
	int size = 0;
	for (int i = 0; this->cha[i] != '\0'; i++)
	{
		size++;
	}
	int size1 = size;
	a = new char[size1 + 1];
	for (int i = 0; i <= size1; i++)
	{
		a[i] = this->cha[i];
	}
	res.cha = new char[len + 1];
	for (int i = 0; i < len; i++)
	{
		res.cha[i] = a[pos + i];
	}
	res.cha[len] = { '\0' };
	return res;
}
int String::length()
{
	int size = 0;
	for (int i = 0; cha[i] != '\0'; i++)
	{
		size++;
	}
	int size1 = size;
	return size1;
}
char String:: at(int i)
{
	return cha[i];
}
