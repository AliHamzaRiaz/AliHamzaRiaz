#include<iostream>
using namespace std;
class Circle{
	int temp;
	double *radius;
	const double pi;
public:
	double circumference() const;
	double area();
	double diameter();

	Circle();
	Circle(double);
	Circle(const Circle&);
	~Circle();
};