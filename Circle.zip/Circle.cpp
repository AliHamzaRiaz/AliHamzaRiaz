#include "Circle.h"

double Circle::circumference() const{
	//temp = 99;
	//float p = 3.14;
	//p = p* pi;
	//*radius = 2.79;
	//radius = new double;
	//radius = nullptr;
	return 2 * pi * *radius;
}
double Circle::area(){
	temp = 99;
	return pi *(*radius)*(*radius);
}
double Circle::diameter(){
	return 2 * *radius;
}
Circle::Circle():pi(22.0/7){
	cout << "Default Constructor" << endl;
	radius = nullptr;
	//pi = 3.14; ==> ERROR 
}
Circle::Circle(double r):pi(22/7.0){
	cout << "Parameterized Constructor" << endl;
	radius = new double;
	*radius = r;
}
Circle::Circle(const Circle& p):pi(22.0/7.0){
	radius = new double;
	*radius = *p.radius;
}
Circle::~Circle(){
	cout << "Destructor" << endl;
	delete radius;
	radius = nullptr;
}