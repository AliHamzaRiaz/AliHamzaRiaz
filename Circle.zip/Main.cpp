#include "Circle.h"

int main(){
	Circle c1;
	Circle c2(2.79);
	//cout<<"C1 area"<<c1.area() << endl;
	cout << "C2 area" << c2.area() << endl;
	const Circle c4(66);
	cout << "C4 circumference" << c4.circumference() << endl;
	//cout << "C4 Area" << c4.area() << endl;
	system("pause");
	return 0;
}